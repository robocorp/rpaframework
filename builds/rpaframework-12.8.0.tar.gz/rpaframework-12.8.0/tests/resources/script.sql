DROP TABLE IF EXISTS orders;
CREATE TABLE orders(id INTEGER PRIMARY KEY, name TEXT);
INSERT INTO orders(id, name) VALUES(1, "my-1st-order"),(2, "my-2nd-order");
