DELETE FROM incoming_orders;
INSERT INTO incoming_orders(asiakas,amount) VALUES("nokia", 5);
INSERT INTO incoming_orders(asiakas,amount) VALUES("microsoft", 3);