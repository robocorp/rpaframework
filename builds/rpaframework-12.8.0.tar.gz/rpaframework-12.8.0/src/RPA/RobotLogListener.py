"""
Dummy module importing core library `RobotLogListener`,
because imports to core package should be done only by
the library itself.
"""
# flake8: noqa
# pylint: disable=unused-import
from RPA.core.logger import RobotLogListener
